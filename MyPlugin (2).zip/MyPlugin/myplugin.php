<?php
/**
 * @package myplugin
 */
 /*
 Plugin Name: myplugin
 Discription: simple plugin
*/


// exist if file is called directly
 add_action( 'the_content', 'my_thank_you_text' );

function my_thank_you_text ( $content ) {
    return $content .= '<p>Thank you for reading my posts..Please keep in touch for more updates!</p>';
}

 if (! defined ('ABSPATH') ) {

 	exist;

 }

if(is_admin()){
 // inculde dependecencies
 	require_once plugin_dir_path(__FILE__) .'admin/admin-menu.php';
 	require_once plugin_dir_path (__FILE__) .'admin/setting-page.php';
}

// register plugin settings
function myplugin_register_settings() {
	
	/*
	
	register_setting( 
		string   $option_group, 
		string   $option_name, 
		callable $sanitize_callback
	);
	
	*/
	
	register_setting( 
		'myplugin_options', 
		'myplugin_options', 
		'myplugin_callback_validate_options' 
	); 

}
add_action( 'admin_init', 'myplugin_register_settings' );


// validate plugin settings
function myplugin_validate_options($input) {

	// todo: add validation functionality..

	return $input;

}
// callback: login section
function myplugin_callback_section_login() {
	
	echo '<p>These settings enable you to customize the WP Login screen.</p>';
	
}



// callback: admin section
function myplugin_callback_section_admin() {
	
	echo '<p>These settings enable you to customize the WP Admin Area.</p>';
	
}












